nums = list(map(int, input("Enter numbers: ").split()))
print(list(set(nums)))