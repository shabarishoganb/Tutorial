s = input("Enter a string: ")
print(s[::2], s[1::2])