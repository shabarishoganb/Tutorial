s = input("Enter a string: ")
old = input("Enter substring to replace: ")
new = input("Enter new substring: ")
print(s.replace(old, new))