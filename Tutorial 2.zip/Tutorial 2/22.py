nums = sorted(map(int, input("Enter numbers: ").split()))
print(nums[len(nums) // 2])