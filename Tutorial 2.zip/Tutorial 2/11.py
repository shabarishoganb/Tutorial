num = int(input("Enter decimal number: "))
print(bin(num)[2:])