import math
r = float(input("Enter radius: "))
print("Area:", math.pi * r * r)