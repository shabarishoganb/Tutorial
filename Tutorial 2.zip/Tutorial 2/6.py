s = input("Enter a string: ")
sub = input("Enter substring to remove: ")
print(s.replace(sub, ""))