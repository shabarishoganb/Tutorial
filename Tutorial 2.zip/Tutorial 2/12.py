num = input("Enter binary number: ")
print(int(num, 2))