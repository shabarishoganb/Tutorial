s = input("Enter a string: ")
print(s.upper())