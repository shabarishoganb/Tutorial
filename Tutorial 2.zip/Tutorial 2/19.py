names = input("Enter names separated by space: ").split()
print(sorted(names))